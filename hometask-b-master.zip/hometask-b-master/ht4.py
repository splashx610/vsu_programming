x = str(input('значение: '))
y = x[::-1]
if x == y:
    print("Полидром ")
else:
    print("не полидром ")
