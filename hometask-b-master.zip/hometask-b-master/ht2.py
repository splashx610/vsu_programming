a = int(input('a = '))
b = int(input('b = '))
c = int(input('c = '))
d = int(input('d = '))
e = int(input('e = '))
de = e - d
if not de:
    print('делить на ноль нельзя')
else:
    print(a*b - c/de)
