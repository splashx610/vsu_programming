x = float(input('x: '))
y = float(input('y: '))
if x < y:
    print('x меньше')
elif x > y:
    print('x больше')
else: 
    print('равны')
