import math
x = int(input('x: '))
y = int(input('y: '))
z = int(input('z: '))
c = x**2 + y**2 + z**2
print(math.sqrt(c))
