x = float(input('x: '))
    if x.is_integer():
        print('целое число ')
    else:
        print('нецелое число ')
